package com.kruger.star.msvcpersonas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcPersonasApplicationTests {

	@Test
	void contextLoads() {
	}

}
